import { useEffect } from "react";
import { useHistory } from "react-router-dom";
import { getLongRedirectUrl } from "../APIs/Read";

function LongUrlsPage() {
  const { location } = useHistory();
  const url_path = location.pathname.split("/")[1];


    useEffect(() => {
        (async () => {
          try {
            if (url_path) {
              const res = await getLongRedirectUrl(url_path);
              if (res && res.data && res.data.data)  {
                window.location.replace(res.data.data.redirect_url);
              }
            }
          
          } catch (error) {}
        })();
        
      },[url_path]);


      return (
          <>
          </>
      );

    }

export default LongUrlsPage;
