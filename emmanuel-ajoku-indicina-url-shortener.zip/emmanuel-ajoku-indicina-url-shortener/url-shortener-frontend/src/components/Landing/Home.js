
import UrlShortener from "./Shortener/UrlShortener";
import React, { useState, useEffect}from 'react';
import TabPanel from "../Tab/TabPanel";
import ManageUrlsLists from "./ManageUrlsList/ManageUrlsList";
import { useFetch } from "../../APIs/Read";

      function Home () {
        const endpoint = '/api/list';
        const token = '';
        const { response, error, isLoading } = useFetch(endpoint, token);
      
        const [responeData, setResponseData] = useState([]);

        useEffect(() => {
          if (response) {
            setResponseData(response);
          }
        }, [response])
        
        function _handleTabChange(index) {
        }
 
          return (
              <>
            <TabPanel onTabChange={_handleTabChange}>
              <div title="Shorten your link">
                <><UrlShortener/> </>
              </div>
              <div title="View all urls list">
               <><ManageUrlsLists data={responeData} /> </>
              </div>
            </TabPanel>
            </>
          );
      }
      


export default Home;
