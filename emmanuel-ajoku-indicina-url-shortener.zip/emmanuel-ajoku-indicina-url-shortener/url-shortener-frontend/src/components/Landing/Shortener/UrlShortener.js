import React, { Component } from "react";
import "./UrlShortener.css";
import { config } from "../../../config/config";
import { encodeLongUrlToShortURL } from "../../../APIs/Create";
import { isValidURL } from "../../../_utils/fx";

class Landing extends Component {
  constructor() {
    super();
    this.state = {
      showShortenUrl: false,
      shortenUrl: "",
      originalUrl: "",
      baseUrl: "",
      clickSubmit: true,
      showError: false,
      alreadyExistError: false,
      apiError: "",
      showApiError: false,
      showLoading: false,
      message: "Unknown api error has occur, please try again",
      exUrl: "https://smallbusiness.withgoogle.com/intl/en-ssa/",
      exShortUrl: config.web.baseUrl
    };
    this.handleUserInput = this.handleUserInput.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
  }
  handleUserInput(e) {
    const name = e.target.name;
    const value = e.target.value;
    this.setState({ [name]: value });
  }
  async handleSubmit() {
    this.setState({ clickSubmit: true, showApiError: false });
    if (this.state.clickSubmit && this.state.originalUrl) {
      this.setState({ showLoading: true, showShortenUrl: false });
      
      let reqObj = {
        original_url: this.state.originalUrl,
        short_base_url: config.web.baseUrl
      };
      const postRes = await encodeLongUrlToShortURL({
        params: reqObj
      })
      if (postRes && postRes.data && postRes.data.data) {
        try {
          setTimeout(() => {
            this.setState({
              showLoading: false,
              showShortenUrl: true,
              shortenUrl: postRes.data.data.full_short_url
            });
          }, 0);

        } catch(e) {
          this.setState({
            showLoading: false,
            showApiError: true,
            apiError: "Server Error"
          });
        }
      } else if ( postRes && postRes.data && postRes.data.message) {
        this.setState({message: postRes.data.message})
        this.setState({ 
          showError: true,
          showLoading: false
        });
      } else {
        this.setState({ 
          showError: true,
          showLoading: false
        });
      }
  }
}
  renderButton() {
    if (!this.state.showLoading) {
      return (
        <button
          className="btn waves-effect waves-light submit-btn"
          name="action"
          onClick={this.handleSubmit}
          disabled={isValidURL(this.state.originalUrl) ? false : true }// && true}
        >
          Submit
        </button>
      );
    } else {
      return (
        <div className="loader">
          <div className="preloader-wrapper small active">
            <div className="spinner-layer spinner-green-only">
              <div className="circle-clipper left">
                <div className="circle" />
              </div>
              <div className="gap-patch">
                <div className="circle" />
              </div>
              <div className="circle-clipper right">
                <div className="circle" />
              </div>
            </div>
          </div>
        </div>
      );
    }
  }
  render() {
    return (
      <div className="landing">
        <div>
          <h5> Paste the URL to be shortened</h5>
        </div>
        <div>
          Please enter longer url exmaple:{" "}
          <a target="_blank" href={this.state.exUrl}>
            {this.state.exUrl}
          </a>
        </div>
        <input
          name="originalUrl"
          field="originalUrl"
          placeholder="Paste your link.."
          value={this.state.originalUrl}
          onChange={this.handleUserInput.bind(this)}
        />

        {this.state.showError && (
          <div className="formError">{this.state.message}</div>
        )}
        {this.renderButton()}
        {this.state.showApiError && (
          <div className="shorten-error">{this.state.apiError}</div>
        )}
        {this.state.showShortenUrl && (
          <div className="shorten-title">
            Shortened Url is -{">"}{` `}
            <a style={{cursor: "pointer"}} 
            onClick={()=> window.open(this.state.originalUrl)}> 
            {this.state.shortenUrl}
            </a>
            
          </div>
        )}
      </div>
    );
  }
}

export default Landing;
