import React, { useEffect, useState} from 'react';
import TableRow from './TablsRow';

 
function Table ({data}) {
    const [responeData, setResponseData] = useState([]);
    useEffect(() => {
      if (data) {
        setResponseData(data);
      }
    }, [data])
  
          return (
              <div className="table-container">
                  <table className="table">
                  <tbody>
                  <tr>
                      <th>id</th>
                      <th>original url</th>
                      <th>full short url</th>
                      <th>hashed long url</th>
                      <th>url path</th>
                      <th>short base url</th>
                      <th>redirected count</th>
                      <th>created at</th>
                      <th>updated at</th>
                  </tr>
                  {responeData.map(function (data, i) {
                      return <TableRow key={'url-' + i}
                          id={data.id}
                          original_url={data.original_url}
                          full_short_url={data.full_short_url}
                          url_hash={data.url_hash}
                          url_path={data.url_path}
                          short_base_url={data.short_base_url}
                          userClicks={data.userClicks}
                          created_at={data.created_at}
                          updated_at={data.updated_at}
                      />
                  })}
              </tbody>
                  </table>
              </div>
          )
      
  
}

  export default Table;