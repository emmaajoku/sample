import React, { Component } from 'react';

class TableRow extends Component {
    render() {
        return (
            <tr>
                  <td>{this.props.id}</td>
                    <td>{this.props.original_url}</td>
                    <td>{this.props.full_short_url}</td>
                    <td>{this.props.url_hash}</td>
                    <td>{this.props.url_path}</td>
                    <td>{this.props.short_base_url}</td>
                    <td>{this.props.userClicks}</td>
                    <td>{this.props.created_at}</td>
                    <td>{this.props.updated_at}</td>
            </tr>
            )
    }
};

export default TableRow;