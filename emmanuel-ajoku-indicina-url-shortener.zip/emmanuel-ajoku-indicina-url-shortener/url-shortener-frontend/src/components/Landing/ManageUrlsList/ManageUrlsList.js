import React, { Component} from 'react';
import UserInput from './UserInput'
import Table from './UrlListTable';

class ManageUrlsList extends Component {
    constructor(props) {
        super(props);
        this.state = {
            search: ''
        };
    }
    
    /**
     * @param {*} event 
     */
    handleChange(event) {
        // Get event value
        let searchValue = event.target.value;
        // Set the state to trigger a re-rendering
        this.setState({ search: searchValue });
    }
    render() {
        // Filter the table data
        let responseData = this.props.data,
            searchString = this.state.search.trim().toLowerCase();

        if (searchString.length > 0) {
            // We are searching. Filter the results.
            responseData = responseData.filter((e) => e.original_url.toLowerCase().match(searchString));
        }
        // Set the `update` property of the `UserInput` element
        return (
            <div>
                <UserInput update={(e) => this.handleChange(e)} />
                <Table data={responseData} />
            </div>
        )
    }
}

export default ManageUrlsList;