import React, { Component } from 'react';
class UserInput extends Component {

    render() {
        return (
        <div>
            <input className="form-control mb-2" 
            placeholder="Search for all type of url..." 
             onChange={(e) => this.props.update(e)} />
        </div>
        )
    }
}

export default UserInput;