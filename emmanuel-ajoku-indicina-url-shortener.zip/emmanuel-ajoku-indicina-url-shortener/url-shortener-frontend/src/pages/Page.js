import React from 'react';

function Page({ children }) {
  return <section id='page'>{children}</section>;
}

export default Page;
