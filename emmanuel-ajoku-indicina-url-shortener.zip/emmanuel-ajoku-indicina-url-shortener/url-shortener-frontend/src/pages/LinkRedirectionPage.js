import React, { lazy, Suspense } from "react";
import { Route, Switch } from "react-router-dom";
import ContentLoader from "../components/Loaders/ContentLoader";
import Page from "./Page";

const LongUrls = lazy(() => import("../components/LongUrls"));

function LongUrlsPage({ page }) {

  return (
    <>
      <Suspense fallback={<ContentLoader />}>
        <Page>
          <Switch>
            <Route exact path={`/:url_path`}>
              <LongUrls />
            </Route>
          </Switch>
        </Page>
      </Suspense>
    </>
  );
}

export default LongUrlsPage;
