import React, { Suspense } from "react";
import { Route, Switch } from "react-router-dom";
import ContentLoader from "./components/Loaders/ContentLoader";
import App from "./components/App";
import LongUrlsPage from "./pages/LinkRedirectionPage";

function Routes() {
  return (
    <Switch>
      <Suspense fallback={<ContentLoader />}>
        <Route path="/" exact>
          <App />
        </Route>
        <Route path="/:url_path">
          <LongUrlsPage />
        </Route>
      </Suspense>
      <Route>
        <h1>Not Found.</h1>
      </Route>
    </Switch>
  );
}

export default Routes;
