const appName = 'url-shortener-frontend';

export const config = {
    environment: process.env.NODE_ENV,
    web: {
        baseUrl: process.env.REACT_APP_BASE_URL,
        port: process.env.WEB_PORT || 8080
    },
    shortener_api: {
        url: process.env.REACT_APP_URL_SHORTENER_API_ENDPOINT
    },
};
