import { baseurl } from "../_utils/fx";

// -> Recipients
function encodeLongUrlToShortURL({ params, token }) {
  const endpoint = `/api/encode`;
  return baseurl.post(
    endpoint,
    { ...params },
    // {
    //   headers: { Authorization: `Bearer ${token}` },
    // }
  );
}
/**
 * 
 * @param {*} params
 * @returns {object | null}
 */
function decodShortURToLongUrl({ params, token }) {
  const endpoint = `/api/decode`;
  return baseurl.post(
    endpoint,
    { ...params },
   // {
    //   headers: { Authorization: `Bearer ${token}` },
    // }
    
  );
}

export { encodeLongUrlToShortURL, decodShortURToLongUrl };
