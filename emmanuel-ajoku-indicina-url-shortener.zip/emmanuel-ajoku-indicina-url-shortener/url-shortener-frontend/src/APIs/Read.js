import { useEffect, useState } from "react";
import { baseurl } from "../_utils/fx";
/**
 * custom hook for fetching data
 * @param endpoint
 * @param token
 * @returns { object | null }
 */
function useFetch(endpoint, token) {
  const [response, setResponse] = useState(null);
  const [error, setError] = useState(null);
  const [isLoading, setIsLoading] = useState(true);

  const reFetch = () => {
    setIsLoading(true);
    (async () => {
      try {
        if (endpoint) {
          const { data } = await baseurl.get(endpoint, {
            // headers: { Authorization: `Bearer ${token}` },
          });
          setResponse(data);
        }
      } catch ({ response }) {
        if (response) {
          if (response.status === 401) {
          } else if (response) {
            setError(response);
          }
        } else {
          setError("SOMETHING WENT WRONG");
        }
      }
      setIsLoading(false);
    })();
  };
  useEffect(() => {
    reFetch();
    // eslint-disable-next-line
  }, [endpoint, token]);

  return { response, error, isLoading, reFetch };
}

/**
 * url redirection
 * @param endpoint
 * @param token
 * @returns { object | null }
 */
function getLongRedirectUrl( endpoint ) {
  return baseurl.get(endpoint, {
  });
}


/**
 * 
 * @param {*} params 
 * @returns {object | null} 
 */
 function getAllurls() {
  const endpoint = `/api/list`;
  return baseurl.get(endpoint, {
  });
}




export { useFetch, getLongRedirectUrl, getAllurls };
