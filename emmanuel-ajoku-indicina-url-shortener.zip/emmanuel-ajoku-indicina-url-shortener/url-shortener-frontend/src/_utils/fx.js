import axios from "axios";
import { config } from "../config/config";

/**
 * Axios baseURL
 * token can also be added here to th header 
 */
const baseurl = axios.create({
  baseURL: config.shortener_api.url.trim(),
});

/**
 * Set item in localStorage
 * @param {*} itemName 
 * @param {*} item 
 */
function setItemInLocalStorage(itemName, item) {
  localStorage.setItem(itemName, JSON.stringify(item));
}

/**
 * Remove Item from localStorage
 * @param {*} itemName 
 */
function removeItemFromLocalStorage(itemName) {
  localStorage.removeItem(itemName);
}

/**
 * Get item from localStorage
 * @param {*} itemName 
 * @returns {object || null}
 */
function getItemFromLocalStorage(itemName) {
  return JSON.parse(localStorage.getItem(itemName));
}

/**
 * @param {*} value 
 * @returns {boolean}
 */
function isObject(value) {
  return value && typeof value === "object" && value.constructor === Object;
}

// 10. Returns true/false if an array is empty
/**
 * 
 * @param {*} array 
 * @returns {bolean}
 */
function isArrayEmpty(array) {
  return array && array.length === 0;
}

/**
 * Confirms if object is empty or not
 * @param {*} obj 
 * @returns {boolean}
 */
function isObjectEmpty(obj) {
  return Object.entries(obj).length === 0 && obj.constructor === Object;
}

/**
 * @param {*} str 
 * @returns 
 */
function isValidURL(str) {
  var pattern = new RegExp('^(https?:\\/\\/)?'+ // protocol
    '((([a-z\\d]([a-z\\d-]*[a-z\\d])*)\\.)+[a-z]{2,}|'+ // domain name
    '((\\d{1,3}\\.){3}\\d{1,3}))'+ // OR ip (v4) address
    '(\\:\\d+)?(\\/[-a-z\\d%_.~+]*)*'+ // port and path
    '(\\?[;&a-z\\d%_.~+=-]*)?'+ // query string
    '(\\#[-a-z\\d_]*)?$','i'); // fragment locator
  return !!pattern.test(str);
}


export {
  baseurl,
  isArrayEmpty,
  isObject,
  isObjectEmpty,
  setItemInLocalStorage,
  removeItemFromLocalStorage,
  getItemFromLocalStorage,
  isValidURL
};
