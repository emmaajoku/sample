module.exports = {
    apps : [{
      name: 'urlshortener_service',
      script: 'yarn start:prod',
  
      // Options reference: https://pm2.keymetrics.io/docs/usage/application-declaration/
      args: 'dist/server.js',
      instances: 1,
      autorestart: true,
      watch: false,
      max_memory_restart: '1G',
    }],
  };
  