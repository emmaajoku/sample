import { PartialType } from '@nestjs/swagger';
import { IsNotEmpty } from 'class-validator';
import { CreateUrlShortenDto } from './create-url-shorten.dto';

export class UpdateUrlShortenDto extends PartialType(CreateUrlShortenDto) {
    @IsNotEmpty()
    url_path: string;

    original_url: string;

}
