import { IsNotEmpty } from 'class-validator';

export class CreateUrlShortenDto {
  readonly id: number;
  
  @IsNotEmpty()
  original_url: string;

  @IsNotEmpty()
  short_base_url: string;
  
  url_hash: string;

  url_path: string;

  full_short_url: string;

  userClicks: number;

  readonly created_at: any;

  readonly updated_at: Date;

  
}
