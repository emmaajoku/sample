import { UrlShortenService } from './url-shorten.service';
import {Module } from '@nestjs/common';
import { UrlShortenController } from './url-shorten.controller';
import { PrismaModule } from 'app/prisma/prisma.module';
import { RedisModule } from 'app/lib/redis/redis.module';

@Module({
  imports: [PrismaModule, RedisModule],
  providers:[UrlShortenService],
  exports: [UrlShortenService ],
  controllers: [UrlShortenController],
})
export class UrlShortenModule { }
