import { RedisCache } from 'app/lib/redis/redis-cache';
import { onFailure, onSuccess, formatDate } from './../lib/utils';
import { UrlShortenService } from './url-shorten.service';
import { Controller, Get, Post, Body, Param, HttpException, HttpStatus, Req, Logger, Query } from '@nestjs/common';
import { CreateUrlShortenDto } from './dto/create-url-shorten.dto';

@Controller()
export class UrlShortenController {
  constructor(
  private readonly redisService: RedisCache,
  private readonly urlShortenService: UrlShortenService,
  ) {}

  /** extrat header
   * @param req 
   * @returns {object} || null
   */
  async headerRequestextractor(req: any): Promise<any> {
    const context: any = {};
    context.user_agent = req.headers['user-agent'];
    context.ip = req.ip;
    return context;
  }

 /**
  * create a short part for a given original url
  * @param req 
  * @param createUrlShortenDto 
  * @returns {object }
  */
  @Post('api/encode')
  async encode(@Body() createUrlShortenDto: CreateUrlShortenDto): Promise<string> {
    // here we want to ensure we same the request with the base url
    try {
      const result: any =  await this.urlShortenService.createUrlShorten(createUrlShortenDto);
      if (result) {
        // we got record
        return onSuccess('successfully encoded long url to short url', result, HttpStatus.CREATED);
      } else if (result === null){
        const alreadyexistResult: any =  await this.urlShortenService.getShortFullUrl(createUrlShortenDto);
       // this we are retuting a failure becasue because the request cannot be fulfilled 
      return onFailure(`Unable to encode url for ${createUrlShortenDto.original_url}, because is already exist with short url: ${alreadyexistResult.full_short_url}`, null, HttpStatus.CONFLICT)
      }
    } catch(e) {
      throw new HttpException(e.toString(),  HttpStatus.FORBIDDEN);
    }
  }
  
  /**
   * decode a given short url part to original url
   * @param url_path
   * @returns {string} 
   */
  @Post('api/decode')
  async decodeUrl(@Body('url_path') url_path: string): Promise<string> {
    try {
    //fetch the entire paylaod for a given short url
    const result = await this.urlShortenService.decodeUrlShorten(url_path);
    if (result) {
      // because we only need to show the user the original url, here we returning the long url only 
      let data = {
        "long_url": result.original_url
      };
      return onSuccess('successfully decoded shor url to long url', data, HttpStatus.OK);
    }
    // this we are retuting a failure becasue because the request cannot be fulfilled 
    return onFailure(`URL for ${url_path}, doesn't exit`, null, HttpStatus.CONFLICT)
  } catch(e) {
    throw new HttpException(e.toString(),  HttpStatus.FORBIDDEN);
  }
  }

  /**
   * return a redict url for a given short url path
   * @param url_path 
   * @returns {string}
   */
  @Get('/:url_path')
  async getRedirectUrl(@Param('url_path') url_path: string): Promise<string> {
    let result: any;
    let data: {};
    let clickCount: number;
    // we have to make call to th db everytime because we need to update the click count
    let resultFromDb = await this.urlShortenService.getShortUrl(url_path);
    if (resultFromDb) {
      clickCount = resultFromDb.userClicks;
      clickCount++;
    } else {
       // this we are retuting a failure becasue because the request cannot be fulfilled 
       return onFailure(`URL for ${url_path}, doesn't exit`, null, HttpStatus.BAD_REQUEST)
    }
    try {
      // result from redis cache
      result = await this.redisService.get(url_path);
      if (!result) {
        // result not found in the cache, so we need to set a new one to the cache database
        this.redisService.set(url_path, resultFromDb, 43200 );
      } else if (result) {
        // the counter must alwaay update wnever a user access this endpoint and got sucess result 
          this.urlShortenService.updateShortUrl(url_path, clickCount);
          // because we want to ensure the user understand the data, we are are now adding and object key: redirect_url
          data = {
            "redirect_url": result.original_url
          };
        return onSuccess('successfully get record', data, HttpStatus.OK);
      } else {
      // this we are retuting a failure becasue because the request cannot be fulfilled 
      return onFailure(`URL for ${url_path}, doesn't exit`, null, HttpStatus.BAD_REQUEST)
      }
    } catch(e) {
      throw new HttpException(e.toString(),  HttpStatus.FORBIDDEN);
    }
  }

  /**
   * get full detail of a given short url
   * @param url_path 
   * @returns {object}
   */
  @Get('api/statistic/:url_path')
  async getStatistic(@Param('url_path') url_path: string): Promise<string> {
    try {
      let result = await this.urlShortenService.getFullDetailOfShortUrl(url_path);
      if (result) {
        delete(result.updated_at);
        result.created_at = formatDate(result.created_at);
        //record was found
        return onSuccess('successfully get record', result, HttpStatus.OK);
      }
     // this we are retuting a failure becasue because the request cannot be fulfilled 
      return onFailure(`URL for ${url_path}, doesn't exit`, null, HttpStatus.CONFLICT)
    } catch(e) {
      throw new HttpException(e.toString(),  HttpStatus.BAD_REQUEST);
    }
  }


  /**
   * get all the records in the database
   * @param req 
   * @returns {object}
   */
  @Get('api/list')
  async getAll(@Query() params: any): Promise<any> {
    try {
      return this.urlShortenService.findAll(params.skip, params.take, params.orderBy, params.searchQuery);
    } catch(e) {
      throw new HttpException(e.toString(), HttpStatus.BAD_REQUEST)
    }

  }

  

}