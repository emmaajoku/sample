
import { Column, Entity, ObjectIdColumn, PrimaryColumn, PrimaryGeneratedColumn } from 'typeorm';
import { Exclude } from 'class-transformer';
import { IsUrl, Length } from 'class-validator';

@Entity({ name: 'UrlShorten' })

export class UrlShorten {
  @PrimaryGeneratedColumn()
  id: number;

  @IsUrl()
  @Length(1, 2000)
  @Column({type: 'varchar', unique: true })
  original_url: string;

  @Column({type: 'varchar', unique: true, length: 100 })
  full_short_url: string;
  
  @Column({length: 32, type: 'varchar', unique: true})
  url_hash: string;

  @Column({type: 'varchar', unique: true})
  url_path: string;

  @Column({type: 'varchar', unique: false})
  short_base_url: string

  @Column({type: 'int', default: 0 })
  userClicks: number;
  
  @Column({ type: 'timestamp', default: () => 'CURRENT_TIMESTAMP'})
  // tslint:disable-next-line: variable-name
  public created_at: Date;

  @Column({ type: 'timestamp', default: () => 'CURRENT_TIMESTAMP', onUpdate: 'CURRENT_TIMESTAMP' })
  // tslint:disable-next-line: variable-name
  public updated_at: Date;
}