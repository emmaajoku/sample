import { UrlShorten } from './entities/url-shorten.entity';
import { Injectable } from '@nestjs/common';
import { CreateUrlShortenDto } from './dto/create-url-shorten.dto';
import { UrlHasher } from '../lib/url-hasher.helper';
import { PrismaService } from 'app/prisma/prisma.service';
import * as ShortId from 'shortid';


@Injectable()
export class UrlShortenService {
    constructor(
      private readonly prismaService: PrismaService
    ) {}

    /**
     * 
     * @param skip 
     * @param take 
     * @param orderBy 
     * @param searchQuery 
     * @returns {object}
     */
    async findAll(skip: number, take: number, orderBy: string, searchQuery: string): Promise<UrlShorten[]> {
      const sortBy: any = orderBy ? orderBy : 'desc';
      // here we return the data base on search query
      if (searchQuery) {
        return this.prismaService.urlShorten.findMany({
          skip: skip,
          take: take || 30,
          where: {
            OR: [
              {
                original_url: { contains: searchQuery },
              },
              {
                url_path: { contains: searchQuery },
              }
            ],
          },
          orderBy: {
            id: sortBy,
          },
        });
      }
      
      //no search query, we are retuning all base on filter
      return this.prismaService.urlShorten.findMany({
        skip: skip,
        take: take || 30,
        orderBy: {
          id: sortBy,
        },
      })
    }
    
    
    /**
     * 
     * @param url_path 
     * @returns 
     */
    async getShortUrl(url_path: string) {
      const result = await this.prismaService.urlShorten.findUnique({
        where: {
          url_path,
        },
      });
      if (result) {
        return result;
      }
      return null;
    }


    /**
     * update value
     * @param updateUrlShortenDto 
     */
    async updateShortUrl(url_path: string, counter: number) {
      const result: any = await this.prismaService.urlShorten.update({
        where: { url_path: url_path },
        data: { userClicks: counter },
      });
      return result;
    }


    /** */
    async getFullDetailOfShortUrl(url_path: string): Promise<UrlShorten> {
      const result =  await this.prismaService.urlShorten.findUnique({
        where: {
          url_path,
        },
      });
      if (result) {
        return result;
      }
      return null;
    }


    /**
     * create short url
     * @param createUrlShortenDto 
     * @returns 
     */
    async createUrlShorten(createUrlShortenDto: CreateUrlShortenDto): Promise<UrlShorten> {
      // hash the original values
      const hashedOriginalUrl = new UrlHasher(createUrlShortenDto.original_url);
      
      // to avoid possible getting hack we are using the hash key for validation
      const existingUrl: object = await this.prismaService.urlShorten.findUnique({where: { url_hash: hashedOriginalUrl.hash }});

        if (existingUrl) {
          // return a fail message because creating duplicate is Forbidden
          return null;
        }
        //generate url part (code) that will be assigning to a giving to a url to be shortning
        const shortCode: string = (ShortId.generate() + ShortId.generate()).replace(/[^\w\d]/, '').substring(0, 6)

        const fullShortUrl: string = `${createUrlShortenDto.short_base_url}${shortCode}`
        // prepaird record creating paylaod
        createUrlShortenDto.url_hash = hashedOriginalUrl.hash;
        createUrlShortenDto.url_path  = shortCode;
        createUrlShortenDto.full_short_url = fullShortUrl;

        return this.prismaService.urlShorten.create({ data: {...createUrlShortenDto } });
  
    }

    /**
     * decode a short url to longer url
     * @param url_path 
     * @returns {string}
     */
    async decodeUrlShorten(url_path: string): Promise<any> {
      // get url__path from short url 
      const url_pathOriginalUrl = url_path.substring(url_path.lastIndexOf('/') + 1);
      const result = await this.prismaService.urlShorten.findUnique({
        where: {
          url_path: url_pathOriginalUrl,
        },
      });
      if (result) {
        return result;
      }
      return null;
    }


    /**
     * @param createUrlShortenDto 
     * @returns {object | null}
     */
   async getShortFullUrl(createUrlShortenDto: CreateUrlShortenDto): Promise<object | null> {
      // hash the original values
      const hashedOriginalUrl = new UrlHasher(createUrlShortenDto.original_url);
      const existingUrl: object = await this.prismaService.urlShorten.findUnique({where: { url_hash: hashedOriginalUrl.hash }});
      return existingUrl
   }
  }

