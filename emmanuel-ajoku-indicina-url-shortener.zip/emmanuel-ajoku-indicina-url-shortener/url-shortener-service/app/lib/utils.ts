import { HttpException, HttpStatus } from "@nestjs/common";
import * as shortid from 'shortid'

/**
 * get condition
 * @param condition 
 * @returns {String}
 */
export const getConditionSymbol = (condition: string): string => {
    switch (condition) {
        case 'eq':
            return '===';
        case 'neq':
            return '!==';
        case 'gt':
            return '>'
        case 'gte':
            return '>='
        default:
            return 'contains';
    }
};

/**
 * custruct the header of the response
 * @param message
 * @param status 
 * @param data 
 * @returns {Object}
 */
 export const getApplicationStatus = (message: string, status: string, data: any, code: number): void => {
    const apiResponse: any = {
      message: message,
      status: status,
      data: data,
      code: code
    }
    return apiResponse;
 }

/**
 * * get data on success
 * @param message 
 * @param status 
 * @param data 
 * @returns
 */
export const onSuccess = (message: string, data: any, code: number ): any => {
    return getApplicationStatus(message, 'success', data, code);
}
 
/**
 * get data on fail
 * @param message 
 * @param status 
 * @param data 
 * @returns {null}
 */
export const onFailure = (message: string, data: any, code: number): any => {
    return getApplicationStatus(message, 'error', data, code);
}
   
/**
* format help method
* @param dateString 
* @returns 
*/
export const formatDate = (dateString: Date): any => {
    const date = new Date(dateString);
    const year = date.getFullYear();
    const day = date.getDate();
    const month = date.getMonth();
    const hours = date.getHours();
    const minutes = date.getMinutes();
    const seconds = date.getSeconds();
 return `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
}


