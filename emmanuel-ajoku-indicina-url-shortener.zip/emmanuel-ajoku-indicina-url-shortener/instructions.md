# url shortener application

## Description
This application is responsible for shortener url. Anyone can you use this application.

## Running the application
This application is complices of 2 diference application to work fully. 


The command below would build and start all dependent containers and take you into the bash temrinal of the main (`urlshortener_web_app`) container:

$ ./bin/start_docker.sh

## Installation

```bash
$ yarn install
```

## Starting (`urlshortener_web_app`)
although the application is listening to port 8000, but the docker is setup to choose any port as it please :
```
app.listen(8000, '0.0.0.0')
```
For view the application in your postman etc, you need to run docker ps ouside the docker container and look for something like this:
399a04bed450   urlshortener_web_app     "docker-entrypoint.s…"   9 hours ago     Up 9 hours     0.0.0.0:51265->5858/tcp, 0.0.0.0:51266->8000/tcp   quizzical_kilby
you notice that we have 2 url, however the one that is expose ouside the docker network it the one that is mapped to *->8000/tcp;
so access the application we would use something like this `0.0.0.0:51266` the port could be any number.

```bash
$ docker ps
```

For local development, the  database and redis details has to be passed into the .env file.

```
DATABASE_HOST=
DATABASE_PORT=
DATABASE_USERNAME=
DATABASE_PASSWORD=
DATABASE_NAME=
DATABASE_TYPE=

REDIS_HOST=
REDIS_PORT=
REDIS_DB=

```
If you need to alter the database, then you will need to change the the app/prisma/schema.prisma and run prisma db command to update your database; because migration file wasn't created because of the way prisma work in docker, so we are still using using ormconfig fo this so you need to change synchronization setting to true in the ormconfig.js file. 
```
 ormconfig.js
"synchronize": true,
```

```bash
$ prisma generate
$ prisma db push
```

```bash
# development
$ yarn run start

# watch mode
$ yarn run start:dev

# production mode
$ yarn run start:prod
```

For managing your database during development use [Docker Adminer](https://beta.docs.docker.com/samples/library/adminer/). It is a web client editor that helps in managing the database. It is already part of the docker services that has been setup in the application.

### How to Use Adminer
When you run this docker command:

```
docker ps
```
* look for the adminer IP address and port.
* run the IP address in your browser to get access to the adminer dashboard.
* you will need to login to get access to the database.
* you can check for the login details in the .env file

## Technology used
[Fastify] (https://www.fastify.io/docs/)

[NestJS] (https://docs.nestjs.com/)
[Prisma] (https://www.prisma.io/docs/)
[TypeORM] (https://typeorm.io/#/)

## Test

### Framework Used
* [Jest] (https://jestjs.io/docs/en/getting-started)

You can run the test by using the following command:

```bash
# unit tests
$ yarn run test

# e2e tests
$ yarn run test:e2e

# test coverage
$ yarn run test:cov
```


## Running the frontend application
Although the appliaction have been setup to use docker, but i didn't have enough time to fix the cross original issue, because the application still misbehaving even though we have add the url to the allowed url to the backend, so it better to run the application without docker for

## Running the (`url-shortener-frontend`) frontend application
This project was bootstrapped with [Create React App](https://github.com/facebook/create-react-app).

For local development, the backend API URL and the application base url has to be passed into the .env file.

```
REACT_APP_URL_SHORTENER_API_ENDPOINT=''

REACT_APP_BASE_URL=''

```
## Available Scripts
In the project directory, you can run:

`yarn start`

Runs the app in the development mode.\
Open [http://localhost:3000](http://localhost:3000) to view it in the browser.

## Cross original 
Alhough the assumsion is the frontend application developement will be (`http://localhost:3000`) but if the port `3000` is already bieng use please ensure that `http://localhost:****` the start anotation is your new port, need to be added to the server.ts file  on the line 22 in the backend (`urlshortener_web_app`) application 

```
  app.enableCors({
      origin: ['http://localhost:3000', '*', '/\.indicina\.com$/']},
  );
```